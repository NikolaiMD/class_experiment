class User {
  constructor(n,u,e,a){
    this.name = n,
    this.username = u,
    this.email = e,
    this.avatar = a,
    this.sayHelloToJack = function(){
      let hello = confirm(`Hi, my name is ${user1.username}.`);
      if(hello == true){
        let html = `
        <div class="Jack_info">
          <div class="outter">
            <p><span>Real name:</span>${user1.name}</p>
            <p><span>User name:</span>${user1.username}</p>
            <p><span>User email:</span>${user1.email}</p>
          </div>
        </div>`;
        let div = document.getElementById('container');
        div.innerHTML = html;
      };
    };
    this.sayHelloToGrinch = function(){
      let hello = confirm(`Hi, my name is ${user2.username}.`);
      if(hello == true){
        let html = `
        <div class="Grinch_info">
          <div class="outter">
            <p><span>Real name:</span>${user2.name}</p>
            <p><span>User name:</span>${user2.username}</p>
            <p><span>User email:</span>${user2.email}</p>
          </div>
        </div>`;
        let div = document.getElementById('container');
        div.innerHTML = html;
      };
    };
    this.sayHelloToBruce = function(){
      let hello = confirm(`Hi, my name is ${user3.username}.`);
      if(hello == true){
        let html = `
        <div class="Bruce_info">
          <div class="outter">
            <p><span>Real name:</span>${user3.name}</p>
            <p><span>User name:</span>${user3.username}</p>
            <p><span>User email:</span>${user3.email}</p>
          </div>
        </div>`;
        let div = document.getElementById('container');
        div.innerHTML = html;
      };
    };
    this.sayHelloToCalvin = function(){
      let hello = confirm(`Hi, my name is ${user4.username}.`);
      if(hello == true){
        let html = `
        <div class="Calvin_info">
          <div class="outter">
            <p><span>Real name:</span>${user4.name}</p>
            <p><span>User name:</span>${user4.username}</p>
            <p><span>User email:</span>${user4.email}</p>
          </div>
        </div>`;
        let div = document.getElementById('container');
        div.innerHTML = html;
      };
    };
  };
};
let user1 = new User("Jack","theripper","freshmeat@mail.ru");
let user2 = new User("Grinch","green_bastard999","IHateChristmas@mail.ru");
let user3 = new User("Bruce","darkknight","WhereIsDetonator@mail.ru");
let user4 = new User("Calvin J. Candie", "candyland", "supervillain@mail.ru");
// alert(`Hi, my name is ${user1.name}, my username is ${user1.username}, my email is ${user1.email}.`);
// console.log(user1.);
