class Cat {
  constructor(a,f){
    this.abilities = a;
    this.fluffy = f;
  }
}
let c1 = new Cat("lazy", true);
let c2 = new Cat("upbeat", false);
let c3 = new Cat("indifferent", true);

console.log(c1,c2,c3);
